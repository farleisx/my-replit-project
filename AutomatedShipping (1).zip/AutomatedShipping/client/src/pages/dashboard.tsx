import MetricsCards from "@/components/metrics-cards";
import CommandCenter from "@/components/command-center";
import SystemStatus from "@/components/system-status";
import OrdersTable from "@/components/orders-table";
import AutomationBuilder from "@/components/automation-builder";
import { Button } from "@/components/ui/button";
import { Search, Download, Zap, ChevronRight, Star, Facebook, Instagram, Youtube, Twitter, Linkedin } from "lucide-react";
import { useEffect, useState } from "react";

export default function Dashboard() {
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);

  const faqData = [
    {
      question: "How do I get started with AutoDropship?",
      answer: "Getting started is simple! Sign up for an account, connect your store, and begin importing products from our extensive supplier network. Our onboarding guide will walk you through each step."
    },
    {
      question: "How do I import products to my store?",
      answer: "Use our one-click import feature to add products directly to your store. Our system automatically imports all product details, images, descriptions, and pricing information."
    },
    {
      question: "How much will I pay after the trial period?",
      answer: "We offer flexible pricing plans starting from $29/month for basic features up to $199/month for enterprise-level automation and unlimited product imports."
    },
    {
      question: "Can I manage more than one store with AutoDropship?",
      answer: "Yes! Our Pro and Enterprise plans allow you to manage multiple stores from a single dashboard, making it easy to scale your dropshipping business."
    },
    {
      question: "Does AutoDropship come with a trial period?",
      answer: "Absolutely! We offer a 14-day free trial with full access to all features so you can experience the power of automated dropshipping before committing."
    },
    {
      question: "Do you have a full-scale order management service?",
      answer: "Yes, our platform includes comprehensive order management with automated fulfillment, tracking updates, and customer notifications to streamline your operations."
    },
    {
      question: "Can I cancel anytime?",
      answer: "Yes, you can cancel your subscription at any time. There are no long-term contracts or cancellation fees. Your account will remain active until the end of your billing period."
    },
    {
      question: "Can AutoDropship help me with tracking?",
      answer: "Our system provides real-time tracking updates and automatically sends tracking information to your customers, keeping everyone informed about order status."
    },
    {
      question: "Will I need to search for products?",
      answer: "Not necessarily! Our AI-powered product research tool can automatically suggest trending products based on your niche and market analysis, saving you hours of manual research."
    },
    {
      question: "Does AutoDropship monitor price and stock?",
      answer: "Yes, we monitor supplier prices and stock levels 24/7. Our system automatically updates your store and can pause products that go out of stock to prevent overselling."
    }
  ];

  const toggleFaq = (index: number) => {
    setExpandedFaq(expandedFaq === index ? null : index);
  };

  useEffect(() => {
    const observerOptions = {
      threshold: 0.1,
      rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.remove('opacity-0', 'translate-y-20');
          entry.target.classList.add('opacity-100', 'translate-y-0');
        }
      });
    }, observerOptions);

    const featureSections = document.querySelectorAll('.feature-section');
    featureSections.forEach((section) => observer.observe(section));

    return () => {
      featureSections.forEach((section) => observer.unobserve(section));
    };
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Dashboard Header */}
        <div className="mb-8 relative">
          <div className="absolute inset-0 bg-gradient-to-r from-purple-600/10 via-pink-600/10 to-indigo-600/10 rounded-3xl blur-3xl"></div>
          <div className="relative bg-white/60 backdrop-blur-sm rounded-2xl p-8 border border-white/20 shadow-xl">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 via-pink-600 to-indigo-600 bg-clip-text text-transparent">
                  Dashboard
                </h1>
                <p className="text-slate-600 text-lg mt-2">
                  Monitor your automated order processing and manage your e-commerce operations
                </p>
              </div>
              <div className="hidden md:flex space-x-2">
                <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full animate-pulse"></div>
                <div className="w-12 h-12 bg-gradient-to-r from-pink-500 to-orange-500 rounded-full animate-pulse" style={{ animationDelay: '0.5s' }}></div>
                <div className="w-12 h-12 bg-gradient-to-r from-orange-500 to-yellow-500 rounded-full animate-pulse" style={{ animationDelay: '1s' }}></div>
              </div>
            </div>
          </div>
        </div>

        {/* Metrics Cards */}
        <MetricsCards />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          {/* Quick Actions */}
          <CommandCenter />

          {/* System Status */}
          <SystemStatus />
        </div>

        {/* Recent Orders Table */}
        <OrdersTable />

        {/* Automation Workflow */}
        <AutomationBuilder />

        {/* Feature Sections */}
        <div className="mt-16 space-y-24">
          {/* Product Research Section */}
          <section className="feature-section opacity-0 translate-y-20 transition-all duration-1000 ease-out">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div className="relative">
                <div className="absolute -inset-4 bg-gradient-to-r from-emerald-400 to-cyan-400 rounded-3xl blur-2xl opacity-20"></div>
                <div className="relative bg-white/80 backdrop-blur-sm rounded-2xl p-8 shadow-2xl border border-white/30">
                  <div className="flex items-center mb-6">
                    <div className="w-12 h-12 bg-gradient-to-r from-emerald-500 to-cyan-500 rounded-full flex items-center justify-center mr-4">
                      <Search className="h-6 w-6 text-white" />
                    </div>
                    <span className="text-sm font-semibold text-emerald-600 uppercase tracking-wider">Find Products</span>
                  </div>
                  <h2 className="text-3xl font-bold text-slate-900 mb-4">
                    Product Research System
                  </h2>
                  <p className="text-slate-600 text-lg mb-6">
                    Instantly compare 8M+ trending products from global suppliers and add to your store in one click. We scan your products price and stock 24/7 for updates.
                  </p>
                  <Button className="bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-white font-semibold px-8 py-3 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
                    Get Started →
                  </Button>
                </div>
              </div>
              <div className="relative">
                <div className="absolute -inset-2 bg-gradient-to-r from-emerald-400 to-cyan-400 rounded-2xl blur-xl opacity-30"></div>
                <div className="relative bg-gradient-to-br from-emerald-50 to-cyan-50 rounded-2xl p-8 overflow-hidden">
                  <div className="bg-white/70 rounded-xl p-6 shadow-lg">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 bg-red-400 rounded-full"></div>
                        <div className="w-3 h-3 bg-yellow-400 rounded-full"></div>
                        <div className="w-3 h-3 bg-green-400 rounded-full"></div>
                      </div>
                      <span className="text-xs text-slate-500">Product Finder</span>
                    </div>
                    <div className="space-y-3">
                      <div className="h-4 bg-gradient-to-r from-emerald-200 to-cyan-200 rounded-full"></div>
                      <div className="h-4 bg-gradient-to-r from-emerald-300 to-cyan-300 rounded-full w-3/4"></div>
                      <div className="h-4 bg-gradient-to-r from-emerald-400 to-cyan-400 rounded-full w-1/2"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Product Import Section */}
          <section className="feature-section opacity-0 translate-y-20 transition-all duration-1000 ease-out">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div className="relative order-2 lg:order-1">
                <div className="absolute -inset-2 bg-gradient-to-r from-blue-400 to-purple-400 rounded-2xl blur-xl opacity-30"></div>
                <div className="relative bg-gradient-to-br from-blue-50 to-purple-50 rounded-2xl p-8 overflow-hidden">
                  <div className="bg-white/70 rounded-xl p-6 shadow-lg">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 bg-red-400 rounded-full"></div>
                        <div className="w-3 h-3 bg-yellow-400 rounded-full"></div>
                        <div className="w-3 h-3 bg-green-400 rounded-full"></div>
                      </div>
                      <span className="text-xs text-slate-500">Import Dashboard</span>
                    </div>
                    <div className="grid grid-cols-3 gap-3 mb-4">
                      <div className="h-8 bg-gradient-to-r from-blue-200 to-purple-200 rounded"></div>
                      <div className="h-8 bg-gradient-to-r from-blue-300 to-purple-300 rounded"></div>
                      <div className="h-8 bg-gradient-to-r from-blue-400 to-purple-400 rounded"></div>
                    </div>
                    <div className="space-y-2">
                      <div className="h-3 bg-gradient-to-r from-blue-200 to-purple-200 rounded-full"></div>
                      <div className="h-3 bg-gradient-to-r from-blue-300 to-purple-300 rounded-full w-4/5"></div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="relative order-1 lg:order-2">
                <div className="absolute -inset-4 bg-gradient-to-r from-blue-400 to-purple-400 rounded-3xl blur-2xl opacity-20"></div>
                <div className="relative bg-white/80 backdrop-blur-sm rounded-2xl p-8 shadow-2xl border border-white/30">
                  <div className="flex items-center mb-6">
                    <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center mr-4">
                      <Download className="h-6 w-6 text-white" />
                    </div>
                    <span className="text-sm font-semibold text-blue-600 uppercase tracking-wider">Import</span>
                  </div>
                  <h2 className="text-3xl font-bold text-slate-900 mb-4">
                    Product Imports
                  </h2>
                  <p className="text-slate-600 text-lg mb-6">
                    Import all product details, including variations, images, titles, descriptions, and product specifics from global suppliers in one click. Use AI to optimize product information.
                  </p>
                  <Button className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white font-semibold px-8 py-3 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
                    Get Started →
                  </Button>
                </div>
              </div>
            </div>
          </section>

          {/* Automation Section */}
          <section className="feature-section opacity-0 translate-y-20 transition-all duration-1000 ease-out">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div className="relative">
                <div className="absolute -inset-4 bg-gradient-to-r from-pink-400 to-rose-400 rounded-3xl blur-2xl opacity-20"></div>
                <div className="relative bg-white/80 backdrop-blur-sm rounded-2xl p-8 shadow-2xl border border-white/30">
                  <div className="flex items-center mb-6">
                    <div className="w-12 h-12 bg-gradient-to-r from-pink-500 to-rose-500 rounded-full flex items-center justify-center mr-4">
                      <Zap className="h-6 w-6 text-white" />
                    </div>
                    <span className="text-sm font-semibold text-pink-600 uppercase tracking-wider">Automate</span>
                  </div>
                  <h2 className="text-3xl font-bold text-slate-900 mb-4">
                    Smart Automation
                  </h2>
                  <p className="text-slate-600 text-lg mb-6">
                    Set up intelligent automations that monitor prices, stock levels, and market trends. Automatically adjust pricing, reorder products, and optimize your inventory management.
                  </p>
                  <Button className="bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 text-white font-semibold px-8 py-3 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
                    Get Started →
                  </Button>
                </div>
              </div>
              <div className="relative">
                <div className="absolute -inset-2 bg-gradient-to-r from-pink-400 to-rose-400 rounded-2xl blur-xl opacity-30"></div>
                <div className="relative bg-gradient-to-br from-pink-50 to-rose-50 rounded-2xl p-8 overflow-hidden">
                  <div className="bg-white/70 rounded-xl p-6 shadow-lg">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 bg-red-400 rounded-full"></div>
                        <div className="w-3 h-3 bg-yellow-400 rounded-full"></div>
                        <div className="w-3 h-3 bg-green-400 rounded-full"></div>
                      </div>
                      <span className="text-xs text-slate-500">Automation Rules</span>
                    </div>
                    <div className="space-y-3">
                      <div className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                        <div className="h-2 bg-gradient-to-r from-pink-200 to-rose-200 rounded-full flex-1"></div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
                        <div className="h-2 bg-gradient-to-r from-pink-300 to-rose-300 rounded-full flex-1"></div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-purple-400 rounded-full animate-pulse"></div>
                        <div className="h-2 bg-gradient-to-r from-pink-400 to-rose-400 rounded-full flex-1"></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>

        {/* FAQ Section */}
        <section className="feature-section opacity-0 translate-y-20 transition-all duration-1000 ease-out mt-24">
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-slate-100/50 via-gray-50/50 to-slate-100/50 rounded-3xl"></div>
            <div className="relative bg-white/60 backdrop-blur-sm rounded-3xl p-12 shadow-2xl border border-white/30">
              <div className="text-center mb-12">
                <h2 className="text-4xl font-bold text-slate-900 mb-4">
                  Frequently Asked Questions
                </h2>
                <p className="text-slate-600 text-lg">
                  Everything you need to know about our automated dropshipping platform
                </p>
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 max-w-6xl mx-auto">
                {faqData.map((faq, index) => (
                  <div
                    key={index}
                    className="group relative overflow-hidden bg-white/70 backdrop-blur-sm rounded-xl border border-white/30 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-[1.02]"
                  >
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                    <button
                      onClick={() => toggleFaq(index)}
                      className="relative w-full p-6 text-left focus:outline-none focus:ring-2 focus:ring-purple-500/20 rounded-xl"
                    >
                      <div className="flex items-center justify-between">
                        <h3 className="text-slate-900 font-semibold text-lg pr-4">
                          {faq.question}
                        </h3>
                        <ChevronRight 
                          className={`h-5 w-5 text-slate-500 transition-transform duration-300 ${
                            expandedFaq === index ? 'rotate-90' : ''
                          }`}
                        />
                      </div>
                      {expandedFaq === index && (
                        <div className="mt-4 pt-4 border-t border-slate-200/50">
                          <p className="text-slate-600 leading-relaxed">
                            {faq.answer}
                          </p>
                        </div>
                      )}
                    </button>
                  </div>
                ))}
              </div>
              
              <div className="text-center mt-12">
                <p className="text-slate-600 mb-6">
                  Still have questions? We're here to help!
                </p>
                <Button className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-semibold px-8 py-3 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
                  Contact Support
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Footer Section */}
        <footer className="mt-24 pt-16 pb-12">
          {/* Ratings Section */}
          <div className="flex justify-center items-center space-x-12 mb-12">
            {/* Shopify Rating */}
            <div className="text-center">
              <div className="flex items-center justify-center mb-2">
                <span className="text-sm font-medium text-slate-600 mr-2">Shopify App Store</span>
              </div>
              <div className="flex items-center justify-center mb-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                ))}
              </div>
              <div className="text-xs text-slate-500">
                <span className="font-semibold">Rating 4.7</span>
                <br />
                <span>1,700+ reviews</span>
              </div>
            </div>

            {/* Trustpilot Rating */}
            <div className="text-center">
              <div className="flex items-center justify-center mb-2">
                <span className="text-sm font-medium text-slate-600 mr-2">Trustpilot</span>
              </div>
              <div className="flex items-center justify-center mb-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-4 w-4 text-green-500 fill-current" />
                ))}
              </div>
              <div className="text-xs text-slate-500">
                <span className="font-semibold">TrustScore 4.9</span>
                <br />
                <span>24,442 reviews</span>
              </div>
            </div>
          </div>

          {/* Social Media Icons */}
          <div className="flex justify-center items-center space-x-4 mb-8">
            <a href="#" className="w-10 h-10 bg-slate-800 hover:bg-slate-700 rounded-lg flex items-center justify-center transition-colors duration-200">
              <Facebook className="h-5 w-5 text-white" />
            </a>
            <a href="#" className="w-10 h-10 bg-slate-800 hover:bg-slate-700 rounded-lg flex items-center justify-center transition-colors duration-200">
              <Instagram className="h-5 w-5 text-white" />
            </a>
            <a href="#" className="w-10 h-10 bg-slate-800 hover:bg-slate-700 rounded-lg flex items-center justify-center transition-colors duration-200">
              <Youtube className="h-5 w-5 text-white" />
            </a>
            <a href="#" className="w-10 h-10 bg-slate-800 hover:bg-slate-700 rounded-lg flex items-center justify-center transition-colors duration-200">
              <Twitter className="h-5 w-5 text-white" />
            </a>
            <a href="#" className="w-10 h-10 bg-slate-800 hover:bg-slate-700 rounded-lg flex items-center justify-center transition-colors duration-200">
              <Linkedin className="h-5 w-5 text-white" />
            </a>
          </div>

          {/* Legal Links */}
          <div className="text-center">
            <div className="flex justify-center items-center space-x-6 text-sm text-slate-500 mb-4">
              <a href="#" className="hover:text-slate-700 transition-colors duration-200">
                Privacy Policy
              </a>
              <span>•</span>
              <a href="#" className="hover:text-slate-700 transition-colors duration-200">
                Terms of Service
              </a>
              <span>•</span>
              <a href="#" className="hover:text-slate-700 transition-colors duration-200">
                Dropshipping Tools
              </a>
            </div>
            <p className="text-xs text-slate-400">
              All rights reserved.
            </p>
          </div>
        </footer>
      </div>
    </div>
  );
}
