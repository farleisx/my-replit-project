import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Star, Zap, Shield, Headphones } from "lucide-react";
import PricingPlans from "@/components/pricing-plans";

export default function Pricing() {
  const features = [
    {
      icon: <Zap className="h-6 w-6" />,
      title: "Lightning Fast Automation",
      description: "Process orders in milliseconds with our optimized automation engine"
    },
    {
      icon: <Shield className="h-6 w-6" />,
      title: "Enterprise Security",
      description: "Bank-level security with SSL encryption and secure API connections"
    },
    {
      icon: <Headphones className="h-6 w-6" />,
      title: "24/7 Support",
      description: "Get help whenever you need it with our dedicated support team"
    }
  ];

  const faqs = [
    {
      question: "How does the automation work?",
      answer: "Our platform monitors your specified conditions (like price changes or stock levels) and automatically executes predefined actions when those conditions are met."
    },
    {
      question: "Can I upgrade or downgrade my plan?",
      answer: "Yes, you can change your plan at any time. Upgrades take effect immediately, while downgrades take effect at the next billing cycle."
    },
    {
      question: "What suppliers do you integrate with?",
      answer: "We integrate with hundreds of suppliers including AliExpress, Amazon, DHgate, and many more. We also support custom API integrations."
    },
    {
      question: "Is there a free trial?",
      answer: "Yes, we offer a 14-day free trial on all plans. No credit card required to get started."
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Page Header */}
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-slate-900 mb-4">
          Simple, Transparent Pricing
        </h1>
        <p className="text-xl text-slate-600 max-w-2xl mx-auto">
          Choose the perfect plan for your dropshipping business. All plans include our core automation features.
        </p>
      </div>

      {/* Pricing Plans */}
      <PricingPlans />

      {/* Features Section */}
      <div className="mb-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">
            Why Choose AutoShip Pro?
          </h2>
          <p className="text-lg text-slate-600">
            Built for modern e-commerce businesses that demand reliability and scale
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card key={index} className="text-center p-6 border-slate-200">
              <CardContent className="pt-6">
                <div className="inline-flex items-center justify-center w-12 h-12 bg-primary/10 rounded-lg mb-4">
                  <div className="text-primary">{feature.icon}</div>
                </div>
                <h3 className="text-xl font-semibold text-slate-900 mb-2">{feature.title}</h3>
                <p className="text-slate-600">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Feature Comparison */}
      <Card className="mb-16">
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-slate-900 text-center">
            Feature Comparison
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-4 font-medium text-slate-900">Feature</th>
                  <th className="text-center py-4 w-32">
                    <div className="font-medium text-slate-900">Basic</div>
                    <div className="text-sm text-slate-500">$29/mo</div>
                  </th>
                  <th className="text-center py-4 w-32 relative">
                    <Badge className="absolute -top-2 left-1/2 transform -translate-x-1/2 bg-primary text-primary-foreground">
                      Popular
                    </Badge>
                    <div className="font-medium text-slate-900 mt-2">Pro</div>
                    <div className="text-sm text-slate-500">$79/mo</div>
                  </th>
                  <th className="text-center py-4 w-32">
                    <div className="font-medium text-slate-900">Enterprise</div>
                    <div className="text-sm text-slate-500">$199/mo</div>
                  </th>
                </tr>
              </thead>
              <tbody>
                {[
                  { feature: "Orders per month", basic: "100", pro: "1,000", enterprise: "Unlimited" },
                  { feature: "Automation rules", basic: "5", pro: "Unlimited", enterprise: "Unlimited" },
                  { feature: "Supplier integrations", basic: "Basic", pro: "Premium", enterprise: "Custom" },
                  { feature: "Advanced analytics", basic: false, pro: true, enterprise: true },
                  { feature: "Priority support", basic: false, pro: true, enterprise: true },
                  { feature: "API access", basic: false, pro: false, enterprise: true },
                  { feature: "White-label options", basic: false, pro: false, enterprise: true },
                  { feature: "Dedicated manager", basic: false, pro: false, enterprise: true },
                ].map((row, index) => (
                  <tr key={index} className="border-b border-slate-100">
                    <td className="py-4 font-medium text-slate-900">{row.feature}</td>
                    <td className="py-4 text-center">
                      {typeof row.basic === 'boolean' ? (
                        row.basic ? <Check className="h-5 w-5 text-emerald-600 mx-auto" /> : <span className="text-slate-300">—</span>
                      ) : (
                        <span className="text-slate-700">{row.basic}</span>
                      )}
                    </td>
                    <td className="py-4 text-center">
                      {typeof row.pro === 'boolean' ? (
                        row.pro ? <Check className="h-5 w-5 text-emerald-600 mx-auto" /> : <span className="text-slate-300">—</span>
                      ) : (
                        <span className="text-slate-700">{row.pro}</span>
                      )}
                    </td>
                    <td className="py-4 text-center">
                      {typeof row.enterprise === 'boolean' ? (
                        row.enterprise ? <Check className="h-5 w-5 text-emerald-600 mx-auto" /> : <span className="text-slate-300">—</span>
                      ) : (
                        <span className="text-slate-700">{row.enterprise}</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* FAQ Section */}
      <div className="mb-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">
            Frequently Asked Questions
          </h2>
          <p className="text-lg text-slate-600">
            Get answers to the most common questions about our platform
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {faqs.map((faq, index) => (
            <Card key={index} className="p-6">
              <CardContent className="pt-0">
                <h3 className="text-lg font-semibold text-slate-900 mb-3">{faq.question}</h3>
                <p className="text-slate-600">{faq.answer}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* CTA Section */}
      <Card className="bg-primary text-primary-foreground text-center p-8">
        <CardContent className="pt-0">
          <Star className="h-12 w-12 mx-auto mb-4 opacity-80" />
          <h2 className="text-3xl font-bold mb-4">Ready to Get Started?</h2>
          <p className="text-lg mb-6 opacity-90">
            Join thousands of successful dropshippers who trust AutoShip Pro
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary" className="bg-white text-primary hover:bg-slate-100">
              Start Free Trial
            </Button>
            <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
              Schedule Demo
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
