import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Instagram, ExternalLink, MessageCircle, Phone, Mail, MapPin, Globe } from "lucide-react";
import { SiInstagram } from "react-icons/si";

export default function Contacts() {
  const contactMethods = [
    {
      icon: <Mail className="h-6 w-6" />,
      title: "Email Support",
      description: "Get help via email",
      contact: "support@autoship.pro",
      color: "from-blue-500 to-cyan-500",
      available: "24/7",
    },
    {
      icon: <Phone className="h-6 w-6" />,
      title: "Phone Support",
      description: "Call us directly",
      contact: "+1 (555) 123-4567",
      color: "from-green-500 to-emerald-500",
      available: "Mon-Fri 9AM-6PM EST",
    },
    {
      icon: <MessageCircle className="h-6 w-6" />,
      title: "Live Chat",
      description: "Chat with our team",
      contact: "Available on website",
      color: "from-purple-500 to-pink-500",
      available: "Mon-Fri 9AM-8PM EST",
    },
  ];

  const officeLocations = [
    {
      city: "New York",
      address: "123 Business Ave, Suite 100",
      zipCode: "New York, NY 10001",
      phone: "+1 (555) 123-4567",
    },
    {
      city: "San Francisco",
      address: "456 Tech Street, Floor 15",
      zipCode: "San Francisco, CA 94105",
      phone: "+1 (555) 987-6543",
    },
    {
      city: "London",
      address: "789 Commerce Road",
      zipCode: "London, UK EC1A 1BB",
      phone: "+44 20 7123 4567",
    },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Page Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-900">Contact Us</h1>
        <p className="text-slate-600">Get in touch with our team for support, partnerships, or general inquiries</p>
      </div>

      {/* Instagram Feature Card */}
      <Card className="mb-8 overflow-hidden border-0 shadow-lg bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-500">
        <CardContent className="p-8 text-white relative">
          <div className="absolute inset-0 bg-black/10"></div>
          <div className="relative z-10">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="p-4 bg-white/20 backdrop-blur-sm rounded-full">
                  <SiInstagram className="h-12 w-12 text-white" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold mb-2">Follow Us on Instagram</h2>
                  <p className="text-white/90 text-lg">
                    Stay updated with the latest news, tips, and behind-the-scenes content
                  </p>
                  <Badge className="mt-2 bg-white/20 text-white border-white/30">
                    @ido_052
                  </Badge>
                </div>
              </div>
              <div className="hidden md:block">
                <div className="grid grid-cols-2 gap-2">
                  <div className="w-16 h-16 bg-white/20 rounded-lg backdrop-blur-sm"></div>
                  <div className="w-16 h-16 bg-white/20 rounded-lg backdrop-blur-sm"></div>
                  <div className="w-16 h-16 bg-white/20 rounded-lg backdrop-blur-sm"></div>
                  <div className="w-16 h-16 bg-white/20 rounded-lg backdrop-blur-sm"></div>
                </div>
              </div>
            </div>
            <div className="mt-6">
              <a
                href="https://www.instagram.com/ido_052/?utm_source=ig_web_button_share_sheet"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block"
              >
                <Button 
                  size="lg" 
                  className="bg-white/20 hover:bg-white/30 backdrop-blur-sm border border-white/30 text-white font-semibold transition-all duration-300 hover:scale-105 shadow-lg"
                >
                  <Instagram className="h-5 w-5 mr-2" />
                  Follow @ido_052
                  <ExternalLink className="h-4 w-4 ml-2" />
                </Button>
              </a>
            </div>
          </div>
          {/* Decorative elements */}
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full translate-x-16 -translate-y-16"></div>
          <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/5 rounded-full -translate-x-12 translate-y-12"></div>
        </CardContent>
      </Card>

      {/* Contact Methods */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        {contactMethods.map((method, index) => (
          <Card key={index} className="shadow-sm border border-slate-200 hover:shadow-md transition-shadow overflow-hidden">
            <CardContent className="p-0">
              <div className={`bg-gradient-to-r ${method.color} p-6 text-white`}>
                <div className="flex items-center justify-between">
                  {method.icon}
                  <Badge className="bg-white/20 text-white border-0">
                    {method.available}
                  </Badge>
                </div>
                <h3 className="text-xl font-semibold mt-4">{method.title}</h3>
                <p className="text-white/90 text-sm">{method.description}</p>
              </div>
              <div className="p-6">
                <p className="font-medium text-slate-900 mb-4">{method.contact}</p>
                <Button className="w-full" variant="outline">
                  Contact Now
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Office Locations */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle className="flex items-center text-xl font-semibold text-slate-900">
            <MapPin className="h-5 w-5 mr-2" />
            Our Offices
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {officeLocations.map((office, index) => (
              <div key={index} className="p-4 border border-slate-200 rounded-lg">
                <h3 className="text-lg font-semibold text-slate-900 mb-2">{office.city}</h3>
                <div className="space-y-2 text-sm text-slate-600">
                  <p>{office.address}</p>
                  <p>{office.zipCode}</p>
                  <p className="flex items-center">
                    <Phone className="h-4 w-4 mr-2" />
                    {office.phone}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Business Hours */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-slate-900">Business Hours</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-slate-600">Monday - Friday</span>
                <span className="font-medium">9:00 AM - 6:00 PM EST</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">Saturday</span>
                <span className="font-medium">10:00 AM - 4:00 PM EST</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">Sunday</span>
                <span className="font-medium">Closed</span>
              </div>
              <div className="pt-2 border-t border-slate-200">
                <div className="flex justify-between">
                  <span className="text-slate-600">Emergency Support</span>
                  <span className="font-medium text-emerald-600">24/7 Available</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-slate-900">Quick Links</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <a href="#" className="flex items-center text-blue-600 hover:text-blue-700 transition-colors">
                <Globe className="h-4 w-4 mr-2" />
                Knowledge Base
              </a>
              <a href="#" className="flex items-center text-blue-600 hover:text-blue-700 transition-colors">
                <MessageCircle className="h-4 w-4 mr-2" />
                Community Forum
              </a>
              <a href="#" className="flex items-center text-blue-600 hover:text-blue-700 transition-colors">
                <ExternalLink className="h-4 w-4 mr-2" />
                API Documentation
              </a>
              <a href="#" className="flex items-center text-blue-600 hover:text-blue-700 transition-colors">
                <Mail className="h-4 w-4 mr-2" />
                Submit Feature Request
              </a>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Contact Form CTA */}
      <Card className="bg-gradient-to-r from-slate-50 to-blue-50 border-blue-200">
        <CardContent className="p-8 text-center">
          <h2 className="text-2xl font-bold text-slate-900 mb-4">Need Personal Assistance?</h2>
          <p className="text-slate-600 mb-6 max-w-2xl mx-auto">
            Our team is here to help you succeed with your dropshipping automation. 
            Get personalized support and guidance from our experts.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-blue-600 hover:bg-blue-700">
              Schedule a Call
            </Button>
            <Button size="lg" variant="outline" className="border-blue-300 text-blue-700 hover:bg-blue-50">
              Send us a Message
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}