import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Plus, Settings, Zap, Wifi } from "lucide-react";

interface Supplier {
  id: number;
  name: string;
  status: string;
  connectionType: string;
  apiEndpoint?: string;
  createdAt: string;
}

export default function Suppliers() {
  const { data: suppliers, isLoading } = useQuery<Supplier[]>({
    queryKey: ["/api/suppliers"],
  });

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "active":
        return "bg-emerald-100 text-emerald-800";
      case "inactive":
        return "bg-slate-100 text-slate-800";
      case "error":
        return "bg-red-100 text-red-800";
      default:
        return "bg-slate-100 text-slate-800";
    }
  };

  const getConnectionIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case "api":
        return <Zap className="h-4 w-4" />;
      case "webhook":
        return <Wifi className="h-4 w-4" />;
      default:
        return <Settings className="h-4 w-4" />;
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  if (isLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900">Suppliers</h1>
          <p className="text-slate-600">Manage your supplier connections and integrations</p>
        </div>
        
        <div className="animate-pulse grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="space-y-3">
                  <div className="h-4 bg-slate-200 rounded w-1/2" />
                  <div className="h-3 bg-slate-200 rounded w-1/3" />
                  <div className="h-3 bg-slate-200 rounded w-2/3" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  const activeSuppliers = suppliers?.filter(s => s.status === 'active').length || 0;
  const totalSuppliers = suppliers?.length || 0;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Page Header */}
      <div className="mb-8">
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Suppliers</h1>
            <p className="text-slate-600">Manage your supplier connections and integrations</p>
          </div>
          <Button className="bg-primary hover:bg-primary/90">
            <Plus className="h-4 w-4 mr-2" />
            Add Supplier
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="p-3 bg-emerald-100 rounded-lg">
                <Zap className="h-6 w-6 text-emerald-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-slate-500">Active Suppliers</p>
                <p className="text-2xl font-bold text-slate-900">{activeSuppliers}</p>
                <p className="text-sm text-emerald-600">All connections healthy</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="p-3 bg-blue-100 rounded-lg">
                <Settings className="h-6 w-6 text-blue-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-slate-500">Total Integrations</p>
                <p className="text-2xl font-bold text-slate-900">{totalSuppliers}</p>
                <p className="text-sm text-slate-500">{totalSuppliers - activeSuppliers} inactive</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="p-3 bg-amber-100 rounded-lg">
                <Wifi className="h-6 w-6 text-amber-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-slate-500">API Requests</p>
                <p className="text-2xl font-bold text-slate-900">2.4K</p>
                <p className="text-sm text-amber-600">Today</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Suppliers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {suppliers?.map((supplier) => (
          <Card key={supplier.id} className="shadow-sm border border-slate-200 hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg font-semibold text-slate-900">
                  {supplier.name}
                </CardTitle>
                <Badge className={`${getStatusColor(supplier.status)} border-0 capitalize`}>
                  {supplier.status}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center text-sm text-slate-600">
                  {getConnectionIcon(supplier.connectionType)}
                  <span className="ml-2 capitalize">{supplier.connectionType} Connection</span>
                </div>
                
                {supplier.apiEndpoint && (
                  <div className="text-sm text-slate-500">
                    <span className="font-medium">Endpoint:</span>
                    <div className="truncate mt-1 font-mono text-xs bg-slate-50 p-2 rounded">
                      {supplier.apiEndpoint}
                    </div>
                  </div>
                )}
                
                <div className="text-sm text-slate-500">
                  <span className="font-medium">Connected:</span> {formatDate(supplier.createdAt)}
                </div>
                
                <div className="pt-3 border-t border-slate-200">
                  <div className="flex justify-between items-center">
                    <div className="text-sm">
                      <div className="font-medium text-slate-900">Response Time</div>
                      <div className="text-slate-500">125ms avg</div>
                    </div>
                    <div className="text-sm">
                      <div className="font-medium text-slate-900">Success Rate</div>
                      <div className="text-emerald-600">99.8%</div>
                    </div>
                  </div>
                </div>
                
                <div className="pt-3 flex gap-2">
                  <Button variant="outline" size="sm" className="flex-1">
                    <Settings className="h-4 w-4 mr-1" />
                    Configure
                  </Button>
                  <Button variant="outline" size="sm" className="flex-1">
                    Test Connection
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
        
        {!suppliers?.length && (
          <Card className="col-span-full">
            <CardContent className="p-12 text-center">
              <div className="text-slate-400 mb-4">
                <Settings className="h-12 w-12 mx-auto" />
              </div>
              <h3 className="text-lg font-medium text-slate-900 mb-2">No suppliers connected</h3>
              <p className="text-slate-600 mb-4">Connect your first supplier to start automating orders</p>
              <Button className="bg-primary hover:bg-primary/90">
                <Plus className="h-4 w-4 mr-2" />
                Add First Supplier
              </Button>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Integration Help */}
      <Card className="mt-8 bg-blue-50 border-blue-200">
        <CardContent className="p-6">
          <div className="flex items-start">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Zap className="h-5 w-5 text-blue-600" />
            </div>
            <div className="ml-4">
              <h3 className="text-lg font-medium text-slate-900 mb-2">Need help integrating suppliers?</h3>
              <p className="text-slate-600 mb-4">
                Our team can help you connect with new suppliers or troubleshoot existing integrations. 
                We support APIs, webhooks, and custom integrations.
              </p>
              <div className="flex gap-3">
                <Button variant="outline" className="border-blue-300 text-blue-700 hover:bg-blue-100">
                  View Documentation
                </Button>
                <Button className="bg-blue-600 hover:bg-blue-700">
                  Contact Support
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
