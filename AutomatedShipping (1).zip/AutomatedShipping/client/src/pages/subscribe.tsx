import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { useEffect, useState } from 'react';
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Check, Star, Zap } from "lucide-react";

// Make sure to call `loadStripe` outside of a component's render to avoid
// recreating the `Stripe` object on every render.
if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
  throw new Error('Missing required Stripe key: VITE_STRIPE_PUBLIC_KEY');
}
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

const SubscribeForm = () => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    const { error } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: window.location.origin + "/dashboard",
      },
    });

    if (error) {
      toast({
        title: "Payment Failed",
        description: error.message,
        variant: "destructive",
      });
    } else {
      toast({
        title: "Welcome to AutoDropship Pro!",
        description: "Your trial has started successfully.",
      });
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <PaymentElement />
      <Button 
        type="submit" 
        disabled={!stripe || !elements}
        className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-semibold py-4 text-lg rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105"
      >
        Start 14-Day Trial for $1
      </Button>
    </form>
  );
};

export default function Subscribe() {
  const [clientSecret, setClientSecret] = useState("");

  useEffect(() => {
    // Create PaymentIntent as soon as the page loads
    apiRequest("POST", "/api/create-subscription")
      .then((res) => res.json())
      .then((data) => {
        setClientSecret(data.clientSecret)
      })
      .catch((error) => {
        console.error('Error creating subscription:', error);
      });
  }, []);

  const features = [
    "Unlimited product imports",
    "Advanced automation rules",
    "Real-time price monitoring",
    "Multi-store management",
    "Priority customer support",
    "Advanced analytics dashboard",
    "Custom branding options",
    "API access"
  ];

  if (!clientSecret) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-pink-50 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-purple-500 border-t-transparent rounded-full" aria-label="Loading"/>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-pink-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 via-pink-600 to-purple-600 bg-clip-text text-transparent mb-4">
            Start Your AutoDropship Journey
          </h1>
          <p className="text-xl text-slate-600">
            Begin your 14-day trial for just $1 and experience the power of automated dropshipping
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Plan Details */}
          <div className="space-y-6">
            <Card className="relative overflow-hidden border-0 bg-gradient-to-br from-purple-50/50 to-pink-50/50 shadow-xl">
              <div className="absolute inset-0 bg-gradient-to-r from-purple-500/5 via-pink-500/5 to-purple-500/5"></div>
              <div className="absolute -top-10 -right-10 w-20 h-20 bg-purple-500/10 rounded-full"></div>
              
              <CardHeader className="relative z-10">
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center">
                    <div className="p-2 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg mr-3">
                      <Zap className="h-6 w-6 text-white" />
                    </div>
                    <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent font-bold text-2xl">
                      Pro Plan
                    </span>
                  </CardTitle>
                  <div className="text-right">
                    <div className="text-3xl font-bold text-slate-900">$1</div>
                    <div className="text-sm text-slate-500">14-day trial</div>
                    <div className="text-xs text-slate-400">then $29/month</div>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="relative z-10">
                <div className="space-y-3">
                  {features.map((feature, index) => (
                    <div key={index} className="flex items-center space-x-3">
                      <div className="flex-shrink-0">
                        <Check className="h-5 w-5 text-green-500" />
                      </div>
                      <span className="text-slate-600">{feature}</span>
                    </div>
                  ))}
                </div>

                <div className="mt-6 p-4 bg-green-50 rounded-xl border border-green-200">
                  <div className="flex items-center space-x-2">
                    <Star className="h-5 w-5 text-green-600" />
                    <span className="text-green-800 font-semibold">Special Offer</span>
                  </div>
                  <p className="text-green-700 text-sm mt-1">
                    Start your journey with a 14-day trial for just $1. Cancel anytime during the trial period.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Payment Form */}
          <div>
            <Card className="relative overflow-hidden border-0 bg-white/80 backdrop-blur-sm shadow-xl">
              <div className="absolute inset-0 bg-gradient-to-r from-purple-500/5 to-pink-500/5"></div>
              
              <CardHeader className="relative z-10">
                <CardTitle className="text-xl font-semibold text-slate-900">
                  Complete Your Subscription
                </CardTitle>
                <p className="text-slate-600">
                  Enter your payment details to start your trial
                </p>
              </CardHeader>
              
              <CardContent className="relative z-10">
                <Elements stripe={stripePromise} options={{ clientSecret }}>
                  <SubscribeForm />
                </Elements>
                
                <div className="mt-6 text-center">
                  <p className="text-xs text-slate-500">
                    By subscribing, you agree to our Terms of Service and Privacy Policy.
                    You can cancel anytime during your trial period.
                  </p>
                </div>

                <div className="mt-4 flex items-center justify-center space-x-4 text-xs text-slate-400">
                  <span>🔒 Secure SSL encryption</span>
                  <span>•</span>
                  <span>💳 Powered by Stripe</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}