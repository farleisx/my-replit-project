import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Plus, Play, Pause, Edit, Trash2 } from "lucide-react";
import AutomationBuilder from "@/components/automation-builder";

interface Automation {
  id: number;
  name: string;
  triggerType: string;
  triggerCondition: string;
  action: string;
  parameters: string;
  isActive: boolean;
  successRate: string;
  lastTriggered: string | null;
  createdAt: string;
}

export default function Automation() {
  const { data: automations, isLoading } = useQuery<Automation[]>({
    queryKey: ["/api/automations/1"],
  });

  const formatLastTriggered = (dateString: string | null) => {
    if (!dateString) return "Never";
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return "Less than 1 hour ago";
    if (diffInHours < 24) return `${diffInHours} hours ago`;
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays} day${diffInDays > 1 ? 's' : ''} ago`;
  };

  const formatCreatedDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  if (isLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900">Automation</h1>
          <p className="text-slate-600">Manage your automated workflows and rules</p>
        </div>
        
        <div className="animate-pulse space-y-4">
          {[1, 2, 3].map((i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="space-y-3">
                  <div className="h-4 bg-slate-200 rounded w-1/4" />
                  <div className="h-3 bg-slate-200 rounded w-1/2" />
                  <div className="h-3 bg-slate-200 rounded w-1/3" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Page Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-900">Automation</h1>
        <p className="text-slate-600">Manage your automated workflows and rules</p>
      </div>

      {/* Automation List */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold text-slate-900">Your Automations</h2>
          <Button className="bg-primary hover:bg-primary/90">
            <Plus className="h-4 w-4 mr-2" />
            New Automation
          </Button>
        </div>

        <div className="grid gap-4">
          {automations?.map((automation) => (
            <Card key={automation.id} className="shadow-sm border border-slate-200">
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <h3 className="text-lg font-medium text-slate-900">{automation.name}</h3>
                      <Badge
                        className={`${
                          automation.isActive
                            ? "bg-emerald-100 text-emerald-800"
                            : "bg-slate-100 text-slate-800"
                        } border-0`}
                      >
                        {automation.isActive ? "Active" : "Inactive"}
                      </Badge>
                    </div>
                    
                    <p className="text-slate-600 mb-3">
                      <span className="font-medium">Trigger:</span> {automation.triggerCondition}
                    </p>
                    <p className="text-slate-600 mb-3">
                      <span className="font-medium">Action:</span> {automation.action}
                    </p>
                    
                    {automation.parameters && (
                      <div className="mb-3">
                        <span className="text-sm font-medium text-slate-700">Parameters:</span>
                        <pre className="text-sm text-slate-600 bg-slate-50 p-2 rounded mt-1 font-mono">
                          {JSON.stringify(JSON.parse(automation.parameters), null, 2)}
                        </pre>
                      </div>
                    )}
                    
                    <div className="flex items-center space-x-6 text-sm text-slate-500">
                      <span>Success rate: <span className="font-medium">{automation.successRate}%</span></span>
                      <span>Last triggered: <span className="font-medium">{formatLastTriggered(automation.lastTriggered)}</span></span>
                      <span>Created: <span className="font-medium">{formatCreatedDate(automation.createdAt)}</span></span>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2 ml-4">
                    <Button
                      variant="outline"
                      size="sm"
                      className={automation.isActive ? "text-amber-600 hover:text-amber-700" : "text-emerald-600 hover:text-emerald-700"}
                    >
                      {automation.isActive ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                    </Button>
                    <Button variant="outline" size="sm">
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="sm" className="text-red-600 hover:text-red-700">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
          
          {!automations?.length && (
            <Card className="shadow-sm border border-slate-200">
              <CardContent className="p-12 text-center">
                <div className="text-slate-400 mb-4">
                  <Plus className="h-12 w-12 mx-auto" />
                </div>
                <h3 className="text-lg font-medium text-slate-900 mb-2">No automations yet</h3>
                <p className="text-slate-600 mb-4">Create your first automation to start automating your workflows</p>
                <Button className="bg-primary hover:bg-primary/90">
                  <Plus className="h-4 w-4 mr-2" />
                  Create First Automation
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Automation Builder */}
      <AutomationBuilder />
    </div>
  );
}
