import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { DollarSign, ShoppingCart, Clock, AlertTriangle, TrendingUp } from "lucide-react";

interface MetricsData {
  totalRevenue: number;
  totalOrders: number;
  activeAutomations: number;
  failedOrders: number;
}

export default function MetricsCards() {
  const { data: metrics, isLoading } = useQuery<MetricsData>({
    queryKey: ["/api/metrics/1"],
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {[1, 2, 3, 4].map((i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-3 bg-slate-100 rounded-lg">
                  <div className="w-6 h-6 bg-slate-200 rounded" />
                </div>
                <div className="ml-4 space-y-2">
                  <div className="h-4 bg-slate-200 rounded w-20" />
                  <div className="h-6 bg-slate-200 rounded w-16" />
                  <div className="h-3 bg-slate-200 rounded w-24" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  const metricCards = [
    {
      title: "Total Revenue",
      value: formatCurrency(metrics?.totalRevenue || 0),
      icon: DollarSign,
      gradient: "from-emerald-500 via-green-500 to-teal-500",
      trend: "12% from last month",
      trendIcon: TrendingUp,
      trendColor: "text-emerald-600",
      bgPattern: "bg-gradient-to-br from-emerald-50/50 to-green-50/50"
    },
    {
      title: "Orders Processed",
      value: (metrics?.totalOrders || 0).toLocaleString(),
      icon: ShoppingCart,
      gradient: "from-blue-500 via-cyan-500 to-indigo-500",
      trend: "8% from last week",
      trendIcon: TrendingUp,
      trendColor: "text-blue-600",
      bgPattern: "bg-gradient-to-br from-blue-50/50 to-cyan-50/50"
    },
    {
      title: "Active Automations",
      value: (metrics?.activeAutomations || 0).toString(),
      icon: Clock,
      gradient: "from-amber-500 via-orange-500 to-yellow-500",
      trend: "Running smoothly",
      trendIcon: null,
      trendColor: "text-amber-600",
      bgPattern: "bg-gradient-to-br from-amber-50/50 to-orange-50/50"
    },
    {
      title: "Failed Orders",
      value: (metrics?.failedOrders || 0).toString(),
      icon: AlertTriangle,
      gradient: "from-red-500 via-pink-500 to-rose-500",
      trend: "Requires attention",
      trendIcon: null,
      trendColor: "text-red-600",
      bgPattern: "bg-gradient-to-br from-red-50/50 to-pink-50/50"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {metricCards.map((metric, index) => (
        <Card 
          key={metric.title} 
          className="group relative overflow-hidden border-0 shadow-xl hover:shadow-2xl transition-all duration-500 hover:scale-105 cursor-pointer"
          style={{
            background: `linear-gradient(135deg, ${metric.bgPattern})`,
          }}
        >
          <div className="absolute inset-0 bg-white/80 backdrop-blur-sm"></div>
          <div className={`absolute inset-0 bg-gradient-to-r ${metric.gradient} opacity-0 group-hover:opacity-10 transition-opacity duration-500`}></div>
          
          {/* Decorative elements */}
          <div className="absolute -top-10 -right-10 w-20 h-20 bg-white/10 rounded-full group-hover:scale-150 transition-transform duration-700"></div>
          <div className="absolute -bottom-5 -left-5 w-10 h-10 bg-white/20 rounded-full group-hover:scale-125 transition-transform duration-500"></div>
          
          <CardContent className="relative z-10 p-6">
            <div className="flex items-start justify-between mb-4">
              <div className={`p-4 bg-gradient-to-r ${metric.gradient} rounded-xl shadow-lg group-hover:shadow-xl transition-all duration-300 group-hover:scale-110`}>
                <metric.icon className="h-6 w-6 text-white" />
              </div>
              <div className="text-right">
                <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></div>
              </div>
            </div>
            
            <div className="space-y-2">
              <p className="text-sm font-semibold text-slate-600 uppercase tracking-wider">{metric.title}</p>
              <p className="text-3xl font-bold bg-gradient-to-r from-slate-800 to-slate-600 bg-clip-text text-transparent group-hover:from-slate-900 group-hover:to-slate-700 transition-all duration-300">
                {metric.value}
              </p>
              <div className={`flex items-center text-sm ${metric.trendColor} font-medium`}>
                {metric.trendIcon && <metric.trendIcon className="h-4 w-4 mr-1" />}
                <span>{metric.trend}</span>
              </div>
            </div>
            
            {/* Progress bar */}
            <div className="mt-4 bg-slate-200 rounded-full h-1 overflow-hidden">
              <div 
                className={`h-full bg-gradient-to-r ${metric.gradient} transition-all duration-1000 ease-out`}
                style={{ width: `${75 + index * 5}%` }}
              ></div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
