import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Check } from "lucide-react";

export default function PricingPlans() {
  const plans = [
    {
      name: "Basic",
      price: 29,
      popular: false,
      paymentLink: "https://buy.stripe.com/test_cNibJ037t2W5gIS6BH4wM01",
      features: [
        "Up to 100 orders/month",
        "5 automation rules",
        "Basic supplier integrations",
        "Email support"
      ]
    },
    {
      name: "Pro",
      price: 79,
      popular: true,
      paymentLink: "https://buy.stripe.com/test_6oU28q7nJgMV1NY0dj4wM02",
      features: [
        "Up to 1000 orders/month",
        "Unlimited automation rules",
        "Premium supplier network",
        "Priority support",
        "Advanced analytics"
      ]
    },
    {
      name: "Enterprise",
      price: 199,
      popular: false,
      paymentLink: "https://buy.stripe.com/test_5kQ00ibDZ409eAK7FL4wM03",
      features: [
        "Unlimited orders",
        "Custom automations",
        "Dedicated account manager",
        "API access",
        "White-label options"
      ]
    }
  ];

  return (
    <Card className="shadow-sm border border-slate-200 mb-8">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-slate-900">
          Subscription Plans
        </CardTitle>
        <p className="text-sm text-slate-600 mt-1">
          Choose the plan that fits your automation needs
        </p>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={`border rounded-lg p-6 relative ${
                plan.popular ? "border-2 border-primary" : "border-slate-200"
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <span className="bg-primary text-primary-foreground px-4 py-1 rounded-full text-sm font-medium">
                    Most Popular
                  </span>
                </div>
              )}
              <div className="text-center">
                <h3 className="text-lg font-semibold text-slate-900">{plan.name}</h3>
                <div className="mt-4">
                  <span className="text-3xl font-bold text-slate-900">${plan.price}</span>
                  <span className="text-slate-500">/month</span>
                </div>
                <ul className="mt-6 space-y-3 text-sm text-slate-600">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-center">
                      <Check className="h-4 w-4 text-emerald-500 mr-2" />
                      {feature}
                    </li>
                  ))}
                </ul>

                {/* WORKING PAYMENT BUTTON */}
                <a
                  href={plan.paymentLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`mt-6 w-full inline-block text-center rounded-md px-4 py-2 text-sm font-medium ${
                    plan.popular
                      ? "bg-primary text-white hover:bg-primary/90"
                      : "border border-primary text-primary hover:bg-primary/10"
                  }`}
                >
                  {plan.name === "Enterprise" ? "Contact Sales" : `Choose ${plan.name}`}
                </a>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
