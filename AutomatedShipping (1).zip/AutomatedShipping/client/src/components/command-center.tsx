import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Search, Play } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface Command {
  id: number;
  command: string;
  status: string;
  createdAt: string;
}

export default function CommandCenter() {
  const [productUrl, setProductUrl] = useState("");
  const [automationCommand, setAutomationCommand] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: recentCommands } = useQuery<Command[]>({
    queryKey: ["/api/commands/1?limit=5"],
  });

  const analyzeProductMutation = useMutation({
    mutationFn: async (url: string) => {
      const response = await apiRequest("POST", "/api/products/analyze", { url });
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Product Analysis Complete",
        description: `Found: ${data.name} - ${data.category}`,
      });
    },
    onError: () => {
      toast({
        title: "Analysis Failed",
        description: "Could not analyze the product URL",
        variant: "destructive",
      });
    },
  });

  const executeCommandMutation = useMutation({
    mutationFn: async (command: string) => {
      const response = await apiRequest("POST", "/api/commands/execute", {
        command,
        userId: 1,
      });
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Command Executed",
        description: data.message,
      });
      setAutomationCommand("");
      queryClient.invalidateQueries({ queryKey: ["/api/commands/1"] });
    },
    onError: () => {
      toast({
        title: "Execution Failed",
        description: "Could not execute the command",
        variant: "destructive",
      });
    },
  });

  const handleAnalyzeProduct = () => {
    if (!productUrl.trim()) {
      toast({
        title: "URL Required",
        description: "Please enter a product URL to analyze",
        variant: "destructive",
      });
      return;
    }
    analyzeProductMutation.mutate(productUrl);
  };

  const handleExecuteCommand = () => {
    if (!automationCommand.trim()) {
      toast({
        title: "Command Required",
        description: "Please enter a command to execute",
        variant: "destructive",
      });
      return;
    }
    executeCommandMutation.mutate(automationCommand);
  };

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return "Just now";
    if (diffInMinutes < 60) return `${diffInMinutes} min ago`;
    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24) return `${diffInHours} hr ago`;
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays} day${diffInDays > 1 ? 's' : ''} ago`;
  };

  return (
    <Card className="lg:col-span-2 group relative overflow-hidden border-0 bg-gradient-to-br from-purple-50/50 to-pink-50/50 shadow-xl hover:shadow-2xl transition-all duration-500">
      <div className="absolute inset-0 bg-gradient-to-r from-purple-500/5 via-pink-500/5 to-indigo-500/5"></div>
      <div className="absolute -top-10 -left-10 w-20 h-20 bg-purple-500/10 rounded-full group-hover:scale-150 transition-transform duration-700"></div>
      
      <CardHeader className="relative z-10">
        <CardTitle className="flex items-center">
          <div className="p-2 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg mr-3 group-hover:scale-110 transition-transform duration-300">
            <Play className="h-5 w-5 text-white" />
          </div>
          <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent font-bold text-lg">
            Quick Command Center
          </span>
          <div className="ml-auto">
            <div className="w-2 h-2 bg-purple-400 rounded-full animate-pulse"></div>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="relative z-10 space-y-6">
        <div className="bg-white/30 rounded-xl p-4 backdrop-blur-sm">
          <Label htmlFor="product-url" className="text-sm font-semibold text-slate-700 mb-3 uppercase tracking-wider block">
            Product URL Analysis
          </Label>
          <div className="flex space-x-3">
            <Input
              id="product-url"
              type="url"
              placeholder="https://example.com/product-url"
              value={productUrl}
              onChange={(e) => setProductUrl(e.target.value)}
              className="flex-1 bg-white/70 border-purple-200 focus:border-purple-400 focus:ring-purple-400/20"
            />
            <Button
              onClick={handleAnalyzeProduct}
              disabled={analyzeProductMutation.isPending}
              className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-semibold px-6 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105"
            >
              <Search className="h-4 w-4 mr-2" />
              {analyzeProductMutation.isPending ? "Analyzing..." : "Analyze"}
            </Button>
          </div>
        </div>

        <div className="bg-white/30 rounded-xl p-4 backdrop-blur-sm">
          <Label htmlFor="automation-command" className="text-sm font-semibold text-slate-700 mb-3 uppercase tracking-wider block">
            Automation Command
          </Label>
          <div className="flex space-x-3">
            <Input
              id="automation-command"
              type="text"
              placeholder="SET quantity=50 WHEN price<$25 ORDER auto"
              value={automationCommand}
              onChange={(e) => setAutomationCommand(e.target.value)}
              className="flex-1 font-mono text-sm bg-white/70 border-emerald-200 focus:border-emerald-400 focus:ring-emerald-400/20"
            />
            <Button
              onClick={handleExecuteCommand}
              disabled={executeCommandMutation.isPending}
              className="bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white font-semibold px-6 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105"
            >
              <Play className="h-4 w-4 mr-2" />
              {executeCommandMutation.isPending ? "Executing..." : "Execute"}
            </Button>
          </div>
          <p className="text-xs text-slate-600 mt-2 bg-white/50 p-2 rounded-lg">
            💡 Use natural language commands to set up automations
          </p>
        </div>

        <div className="pt-4 border-t border-white/30">
          <h3 className="text-sm font-semibold text-slate-700 mb-4 uppercase tracking-wider flex items-center">
            <div className="w-3 h-3 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full mr-2"></div>
            Recent Commands
          </h3>
          <div className="space-y-3">
            {recentCommands?.map((command, index) => (
              <div key={command.id} className="group relative overflow-hidden bg-white/40 backdrop-blur-sm rounded-xl p-4 border border-white/30 hover:bg-white/60 transition-all duration-300 hover:scale-[1.02]">
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                <div className="relative flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className={`w-3 h-3 rounded-full animate-pulse ${
                      command.status === 'executed' 
                        ? 'bg-gradient-to-r from-emerald-400 to-green-500' 
                        : 'bg-gradient-to-r from-blue-400 to-cyan-500'
                    }`} />
                    <span className="text-sm font-mono text-slate-700 bg-slate-100/50 px-2 py-1 rounded-md">
                      {command.command}
                    </span>
                    <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                      command.status === 'executed'
                        ? 'bg-emerald-100 text-emerald-700'
                        : 'bg-blue-100 text-blue-700'
                    }`}>
                      {command.status}
                    </div>
                  </div>
                  <span className="text-xs text-slate-500 bg-white/50 px-2 py-1 rounded-full">
                    {formatTimeAgo(command.createdAt)}
                  </span>
                </div>
              </div>
            ))}
            {!recentCommands?.length && (
              <div className="text-center py-8 bg-white/30 rounded-xl backdrop-blur-sm">
                <div className="w-16 h-16 bg-gradient-to-r from-purple-200 to-pink-200 rounded-full mx-auto mb-3 flex items-center justify-center">
                  <Play className="h-8 w-8 text-purple-500" />
                </div>
                <p className="text-sm text-slate-600 font-medium">
                  No recent commands
                </p>
                <p className="text-xs text-slate-500 mt-1">
                  Execute your first automation command above
                </p>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
