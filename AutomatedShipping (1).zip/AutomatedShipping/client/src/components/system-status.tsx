import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface QueueStatus {
  pending: number;
  processing: number;
  completed: number;
}

export default function SystemStatus() {
  const { data: queueStatus } = useQuery<QueueStatus>({
    queryKey: ["/api/queue-status"],
  });

  const systemServices = [
    {
      name: "Order Processing",
      status: "online",
      color: "emerald"
    },
    {
      name: "Supplier Connections",
      status: "8/8 Active",
      color: "emerald"
    },
    {
      name: "Payment Gateway",
      status: "Connected",
      color: "emerald"
    },
    {
      name: "API Rate Limit",
      status: "75% Used",
      color: "amber"
    }
  ];

  const getStatusColor = (color: string) => {
    switch (color) {
      case "emerald":
        return "bg-emerald-500";
      case "amber":
        return "bg-amber-500";
      case "red":
        return "bg-red-500";
      default:
        return "bg-slate-500";
    }
  };

  const getTextColor = (color: string) => {
    switch (color) {
      case "emerald":
        return "text-emerald-600";
      case "amber":
        return "text-amber-600";
      case "red":
        return "text-red-600";
      default:
        return "text-slate-600";
    }
  };

  return (
    <Card className="shadow-sm border border-slate-200">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-slate-900">
          System Status
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {systemServices.map((service) => (
          <div key={service.name} className="flex items-center justify-between">
            <span className="text-sm text-slate-600">{service.name}</span>
            <div className="flex items-center">
              <div className={`w-2 h-2 ${getStatusColor(service.color)} rounded-full mr-2`} />
              <span className={`text-sm font-medium ${getTextColor(service.color)}`}>
                {service.status}
              </span>
            </div>
          </div>
        ))}

        <div className="mt-6 pt-4 border-t border-slate-200">
          <h3 className="text-sm font-medium text-slate-900 mb-3">Queue Status</h3>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-slate-600">Pending Orders</span>
              <span className="font-medium">{queueStatus?.pending || 0}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-slate-600">Processing</span>
              <span className="font-medium text-blue-600">{queueStatus?.processing || 0}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-slate-600">Completed Today</span>
              <span className="font-medium text-emerald-600">{queueStatus?.completed || 0}</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
