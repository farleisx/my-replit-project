import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Check, Star, Zap, Crown, Sparkles, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

interface SubscriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function SubscriptionModal({ isOpen, onClose }: SubscriptionModalProps) {
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [isYearly, setIsYearly] = useState(false);

  const plans = [
    {
      id: "basic",
      name: "Basic",
      monthlyPrice: 29,
      yearlyPrice: 24,
      popular: false,
      color: "from-blue-500 to-cyan-500",
      icon: <Zap className="h-6 w-6" />,
      features: [
        "Up to 100 orders/month",
        "5 automation rules",
        "Basic supplier integrations",
        "Email support",
        "Order tracking dashboard",
        "Basic analytics"
      ]
    },
    {
      id: "pro",
      name: "Pro",
      monthlyPrice: 79,
      yearlyPrice: 65,
      popular: true,
      color: "from-purple-500 to-pink-500",
      icon: <Star className="h-6 w-6" />,
      features: [
        "Up to 1,000 orders/month",
        "Unlimited automation rules",
        "Premium supplier network",
        "Priority support",
        "Advanced analytics",
        "Custom workflows",
        "API access",
        "Real-time notifications"
      ]
    },
    {
      id: "enterprise",
      name: "Enterprise",
      monthlyPrice: 199,
      yearlyPrice: 165,
      popular: false,
      color: "from-amber-500 to-orange-500",
      icon: <Crown className="h-6 w-6" />,
      features: [
        "Unlimited orders",
        "Custom automations",
        "Dedicated account manager",
        "Full API access",
        "White-label options",
        "Custom integrations",
        "24/7 phone support",
        "SLA guarantee"
      ]
    }
  ];

  const getPrice = (plan: any) => {
    return isYearly ? plan.yearlyPrice : plan.monthlyPrice;
  };

  const getSavings = (plan: any) => {
    return Math.round(((plan.monthlyPrice * 12 - plan.yearlyPrice * 12) / (plan.monthlyPrice * 12)) * 100);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto p-0">
        <div className="relative">
          {/* Header with gradient background */}
          <div className="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 p-8 text-white relative overflow-hidden">
            <div className="absolute inset-0 bg-black/10"></div>
            <button
              onClick={onClose}
              className="absolute top-4 right-4 text-white/80 hover:text-white transition-colors z-10"
            >
              <X className="h-6 w-6" />
            </button>
            
            <div className="relative z-10">
              <DialogHeader>
                <div className="flex items-center justify-center mb-4">
                  <Sparkles className="h-8 w-8 mr-3 text-yellow-300" />
                  <DialogTitle className="text-3xl font-bold text-center">
                    Choose Your Plan
                  </DialogTitle>
                </div>
                <p className="text-xl text-center text-white/90 max-w-2xl mx-auto">
                  Unlock the full potential of automated dropshipping with our feature-rich plans
                </p>
              </DialogHeader>

              {/* Billing Toggle */}
              <div className="flex items-center justify-center mt-8">
                <div className="bg-white/20 backdrop-blur-sm rounded-full p-1 flex items-center">
                  <button
                    onClick={() => setIsYearly(false)}
                    className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                      !isYearly
                        ? "bg-white text-purple-600 shadow-md"
                        : "text-white/80 hover:text-white"
                    }`}
                  >
                    Monthly
                  </button>
                  <button
                    onClick={() => setIsYearly(true)}
                    className={`px-4 py-2 rounded-full text-sm font-medium transition-all relative ${
                      isYearly
                        ? "bg-white text-purple-600 shadow-md"
                        : "text-white/80 hover:text-white"
                    }`}
                  >
                    Yearly
                    <Badge className="absolute -top-2 -right-2 bg-yellow-400 text-yellow-900 text-xs">
                      Save 20%
                    </Badge>
                  </button>
                </div>
              </div>
            </div>

            {/* Decorative elements */}
            <div className="absolute top-0 left-0 w-32 h-32 bg-white/10 rounded-full -translate-x-16 -translate-y-16"></div>
            <div className="absolute bottom-0 right-0 w-24 h-24 bg-white/10 rounded-full translate-x-12 translate-y-12"></div>
          </div>

          {/* Plans Grid */}
          <div className="p-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {plans.map((plan, index) => (
                <motion.div
                  key={plan.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="relative"
                >
                  <Card
                    className={`relative overflow-hidden border-2 transition-all duration-300 hover:scale-105 hover:shadow-xl cursor-pointer ${
                      plan.popular
                        ? "border-purple-500 shadow-lg shadow-purple-500/25"
                        : selectedPlan === plan.id
                        ? "border-blue-500 shadow-lg"
                        : "border-slate-200 hover:border-slate-300"
                    }`}
                    onClick={() => setSelectedPlan(plan.id)}
                  >
                    {/* Popular badge */}
                    {plan.popular && (
                      <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 z-10">
                        <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-4 py-1 text-sm font-medium">
                          Most Popular
                        </Badge>
                      </div>
                    )}

                    {/* Gradient header */}
                    <div className={`bg-gradient-to-r ${plan.color} p-6 text-white relative`}>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          {plan.icon}
                          <h3 className="text-xl font-bold ml-2">{plan.name}</h3>
                        </div>
                        {selectedPlan === plan.id && (
                          <motion.div
                            initial={{ scale: 0 }}
                            animate={{ scale: 1 }}
                            className="bg-white/20 rounded-full p-1"
                          >
                            <Check className="h-4 w-4" />
                          </motion.div>
                        )}
                      </div>
                      
                      <div className="mt-4">
                        <div className="flex items-baseline">
                          <span className="text-3xl font-bold">${getPrice(plan)}</span>
                          <span className="text-white/80 ml-1">/{isYearly ? "month" : "month"}</span>
                        </div>
                        {isYearly && (
                          <div className="text-sm text-white/80 mt-1">
                            Billed yearly • Save {getSavings(plan)}%
                          </div>
                        )}
                      </div>
                    </div>

                    <CardContent className="p-6">
                      <ul className="space-y-3">
                        {plan.features.map((feature, featureIndex) => (
                          <motion.li
                            key={featureIndex}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: (index * 0.1) + (featureIndex * 0.05) }}
                            className="flex items-center text-sm"
                          >
                            <Check className="h-4 w-4 text-emerald-500 mr-3 flex-shrink-0" />
                            <span className="text-slate-700">{feature}</span>
                          </motion.li>
                        ))}
                      </ul>

                      <Button
                        className={`w-full mt-6 transition-all duration-300 ${
                          plan.popular
                            ? "bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white shadow-lg"
                            : selectedPlan === plan.id
                            ? "bg-blue-500 hover:bg-blue-600 text-white"
                            : "border border-slate-300 text-slate-700 hover:bg-slate-50"
                        }`}
                        variant={plan.popular || selectedPlan === plan.id ? "default" : "outline"}
                      >
                        {plan.id === "enterprise" ? "Contact Sales" : "Get Started"}
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>

            {/* Additional Features */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="mt-8 p-6 bg-gradient-to-r from-slate-50 to-blue-50 rounded-xl border border-slate-200"
            >
              <div className="text-center">
                <h3 className="text-lg font-semibold text-slate-900 mb-2">All plans include:</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-slate-600">
                  <div className="flex items-center justify-center">
                    <Check className="h-4 w-4 text-emerald-500 mr-2" />
                    SSL Security & Encryption
                  </div>
                  <div className="flex items-center justify-center">
                    <Check className="h-4 w-4 text-emerald-500 mr-2" />
                    99.9% Uptime Guarantee
                  </div>
                  <div className="flex items-center justify-center">
                    <Check className="h-4 w-4 text-emerald-500 mr-2" />
                    14-day Free Trial
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Bottom CTA */}
            <div className="text-center mt-8">
              <p className="text-slate-600 mb-4">
                Need a custom solution? Our enterprise team can create a plan tailored to your needs.
              </p>
              <Button variant="outline" className="border-purple-300 text-purple-600 hover:bg-purple-50">
                Contact Enterprise Sales
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}