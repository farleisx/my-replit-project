import { Link, useLocation } from "wouter";
import { Truck, Bell, ChevronDown, User, Settings, CreditCard, LogOut } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { useState } from "react";
import SubscriptionModal from "@/components/subscription-modal";

export default function Navbar() {
  const [location] = useLocation();
  const [isSubscriptionModalOpen, setIsSubscriptionModalOpen] = useState(false);

  const isActive = (path: string) => {
    if (path === "/" && (location === "/" || location === "/dashboard")) return true;
    return location === path;
  };

  const navItems = [
    { name: "Dashboard", path: "/", icon: null },
    { name: "Automation", path: "/automation", icon: null },
    { name: "Orders", path: "/orders", icon: null },
    { name: "Suppliers", path: "/suppliers", icon: null },
    { name: "Contacts", path: "/contacts", icon: null },
  ];

  return (
    <nav className="bg-white border-b border-slate-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <Truck className="text-primary text-2xl mr-2" />
              <span className="text-xl font-bold text-slate-900">AutoShip Pro</span>
            </div>
            <div className="hidden md:ml-8 md:flex md:space-x-8">
              {navItems.map((item) => (
                <Link
                  key={item.path}
                  href={item.path}
                  className={`px-1 pt-1 pb-4 text-sm font-medium border-b-2 transition-colors ${
                    isActive(item.path)
                      ? "text-primary border-primary"
                      : "text-slate-500 hover:text-slate-700 border-transparent hover:border-slate-300"
                  }`}
                >
                  {item.name}
                </Link>
              ))}
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <button className="text-slate-400 hover:text-slate-500">
              <Bell className="h-5 w-5" />
            </button>
            <DropdownMenu>
              <DropdownMenuTrigger className="flex items-center space-x-2 hover:bg-slate-50 px-2 py-1 rounded-md transition-colors">
                <Avatar className="h-8 w-8">
                  <AvatarImage src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150" />
                  <AvatarFallback>JD</AvatarFallback>
                </Avatar>
                <span className="text-sm font-medium text-slate-700 hidden sm:block">John Doe</span>
                <ChevronDown className="h-4 w-4 text-slate-400" />
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuItem className="flex items-center">
                  <User className="h-4 w-4 mr-2" />
                  Profile
                </DropdownMenuItem>
                <DropdownMenuItem className="flex items-center">
                  <Settings className="h-4 w-4 mr-2" />
                  Settings
                </DropdownMenuItem>
                <DropdownMenuItem 
                  className="flex items-center cursor-pointer"
                  onClick={() => setIsSubscriptionModalOpen(true)}
                >
                  <CreditCard className="h-4 w-4 mr-2" />
                  Subscription Plans
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="flex items-center text-red-600">
                  <LogOut className="h-4 w-4 mr-2" />
                  Log out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>

      <SubscriptionModal 
        isOpen={isSubscriptionModalOpen} 
        onClose={() => setIsSubscriptionModalOpen(false)} 
      />
    </nav>
  );
}
