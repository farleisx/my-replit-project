import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Plus, Edit } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface Automation {
  id: number;
  name: string;
  triggerType: string;
  triggerCondition: string;
  action: string;
  parameters: string;
  isActive: boolean;
  successRate: string;
  lastTriggered: string | null;
}

export default function AutomationBuilder() {
  const [name, setName] = useState("");
  const [triggerType, setTriggerType] = useState("");
  const [action, setAction] = useState("");
  const [parameters, setParameters] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: automations } = useQuery<Automation[]>({
    queryKey: ["/api/automations/1"],
  });

  const createAutomationMutation = useMutation({
    mutationFn: async (automationData: any) => {
      const response = await apiRequest("POST", "/api/automations", automationData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Automation Created",
        description: "Your automation has been successfully created",
      });
      setName("");
      setTriggerType("");
      setAction("");
      setParameters("");
      queryClient.invalidateQueries({ queryKey: ["/api/automations/1"] });
    },
    onError: () => {
      toast({
        title: "Creation Failed",
        description: "Could not create the automation",
        variant: "destructive",
      });
    },
  });

  const handleCreateAutomation = () => {
    if (!name || !triggerType || !action) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    createAutomationMutation.mutate({
      userId: 1,
      name,
      triggerType,
      triggerCondition: getTriggerCondition(triggerType),
      action,
      parameters,
      isActive: true,
    });
  };

  const getTriggerCondition = (type: string) => {
    switch (type) {
      case "price_condition":
        return "price < threshold";
      case "stock_level":
        return "stock changes";
      case "new_product":
        return "new product available";
      case "schedule":
        return "scheduled time";
      default:
        return "";
    }
  };

  const formatLastTriggered = (dateString: string | null) => {
    if (!dateString) return "Never";
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return "Less than 1 hour ago";
    if (diffInHours < 24) return `${diffInHours} hours ago`;
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays} day${diffInDays > 1 ? 's' : ''} ago`;
  };

  return (
    <Card className="shadow-sm border border-slate-200">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-slate-900">
          Automation Workflow Builder
        </CardTitle>
        <p className="text-sm text-slate-600 mt-1">
          Create intelligent automation rules for your orders
        </p>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div>
            <h3 className="text-sm font-medium text-slate-900 mb-4">Create New Automation</h3>
            <div className="space-y-4">
              <div>
                <Label htmlFor="automation-name">Automation Name</Label>
                <Input
                  id="automation-name"
                  placeholder="My Automation"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
              </div>
              
              <div>
                <Label htmlFor="trigger-condition">Trigger Condition</Label>
                <Select value={triggerType} onValueChange={setTriggerType}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select trigger condition" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="price_condition">Price drops below threshold</SelectItem>
                    <SelectItem value="stock_level">Stock level changes</SelectItem>
                    <SelectItem value="new_product">New product available</SelectItem>
                    <SelectItem value="schedule">Scheduled time</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="action">Action</Label>
                <Select value={action} onValueChange={setAction}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select action" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="place_order">Place order automatically</SelectItem>
                    <SelectItem value="send_notification">Send notification</SelectItem>
                    <SelectItem value="update_inventory">Update inventory</SelectItem>
                    <SelectItem value="generate_report">Generate report</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="parameters">Parameters</Label>
                <Textarea
                  id="parameters"
                  placeholder={`quantity: 25\nmax_price: $50\nnotify_email: user@example.com`}
                  value={parameters}
                  onChange={(e) => setParameters(e.target.value)}
                  className="h-20 font-mono text-sm"
                />
              </div>
              
              <Button
                onClick={handleCreateAutomation}
                disabled={createAutomationMutation.isPending}
                className="w-full bg-primary hover:bg-primary/90"
              >
                <Plus className="h-4 w-4 mr-2" />
                {createAutomationMutation.isPending ? "Creating..." : "Create Automation"}
              </Button>
            </div>
          </div>

          <div>
            <h3 className="text-sm font-medium text-slate-900 mb-4">Active Automations</h3>
            <div className="space-y-3">
              {automations?.map((automation) => (
                <div key={automation.id} className="p-4 border border-slate-200 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="text-sm font-medium text-slate-900">{automation.name}</h4>
                    <div className="flex items-center space-x-2">
                      <Badge
                        className={`${
                          automation.isActive
                            ? "bg-emerald-100 text-emerald-800"
                            : "bg-slate-100 text-slate-800"
                        } border-0`}
                      >
                        {automation.isActive ? "Active" : "Inactive"}
                      </Badge>
                      <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                        <Edit className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                  <p className="text-sm text-slate-600 mb-2">
                    When {automation.triggerCondition}, {automation.action}
                  </p>
                  <div className="flex justify-between text-xs text-slate-500">
                    <span>Last triggered: {formatLastTriggered(automation.lastTriggered)}</span>
                    <span>Success rate: {automation.successRate}%</span>
                  </div>
                </div>
              ))}
              {!automations?.length && (
                <p className="text-sm text-slate-500 text-center py-8">
                  No automations created yet
                </p>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
