import { 
  users, products, suppliers, orders, automations, commands,
  type User, type Product, type Supplier, type Order, type Automation, type Command,
  type InsertUser, type InsertProduct, type InsertSupplier, type InsertOrder, 
  type InsertAutomation, type InsertCommand 
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserStripeInfo(userId: number, stripeCustomerId: string, stripeSubscriptionId: string): Promise<User | undefined>;

  // Product operations
  getProducts(userId: number): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, updates: Partial<Product>): Promise<Product | undefined>;

  // Supplier operations
  getSuppliers(): Promise<Supplier[]>;
  getSupplier(id: number): Promise<Supplier | undefined>;
  createSupplier(supplier: InsertSupplier): Promise<Supplier>;

  // Order operations
  getOrders(userId: number): Promise<Order[]>;
  getRecentOrders(userId: number, limit: number): Promise<Order[]>;
  getOrder(id: number): Promise<Order | undefined>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrderStatus(id: number, status: string): Promise<Order | undefined>;

  // Automation operations
  getAutomations(userId: number): Promise<Automation[]>;
  getAutomation(id: number): Promise<Automation | undefined>;
  createAutomation(automation: InsertAutomation): Promise<Automation>;
  updateAutomation(id: number, updates: Partial<Automation>): Promise<Automation | undefined>;

  // Command operations
  getRecentCommands(userId: number, limit: number): Promise<Command[]>;
  createCommand(command: InsertCommand): Promise<Command>;

  // Analytics
  getOrderMetrics(userId: number): Promise<{
    totalRevenue: number;
    totalOrders: number;
    activeAutomations: number;
    failedOrders: number;
  }>;

  getQueueStatus(): Promise<{
    pending: number;
    processing: number;
    completed: number;
  }>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User> = new Map();
  private products: Map<number, Product> = new Map();
  private suppliers: Map<number, Supplier> = new Map();
  private orders: Map<number, Order> = new Map();
  private automations: Map<number, Automation> = new Map();
  private commands: Map<number, Command> = new Map();
  private currentId = 1;

  constructor() {
    this.seedData();
  }

  private seedData() {
    // Create default user
    const defaultUser: User = {
      id: 1,
      username: "demo",
      password: "password",
      email: "demo@example.com",
      subscriptionPlan: "pro",
      stripeCustomerId: null,
      stripeSubscriptionId: null,
      createdAt: new Date(),
    };
    this.users.set(1, defaultUser);

    // Create suppliers
    const suppliers: Supplier[] = [
      { id: 1, name: "TechSupply Co.", status: "active", connectionType: "api", apiEndpoint: "https://api.techsupply.com", createdAt: new Date() },
      { id: 2, name: "SportsDirect", status: "active", connectionType: "api", apiEndpoint: "https://api.sportsdirect.com", createdAt: new Date() },
      { id: 3, name: "MobileMax", status: "active", connectionType: "webhook", apiEndpoint: "https://webhook.mobilemax.com", createdAt: new Date() },
    ];
    suppliers.forEach(supplier => this.suppliers.set(supplier.id, supplier));

    // Create products
    const products: Product[] = [
      {
        id: 1,
        userId: 1,
        name: "Wireless Earbuds Pro",
        url: "https://example.com/wireless-earbuds",
        category: "Electronics",
        price: "89.99",
        supplierId: 1,
        imageUrl: "https://images.unsplash.com/photo-1572569511254-d8f925fe2cbb?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
        createdAt: new Date(),
      },
      {
        id: 2,
        userId: 1,
        name: "Running Sneakers",
        url: "https://example.com/running-sneakers",
        category: "Footwear",
        price: "124.50",
        supplierId: 2,
        imageUrl: "https://images.unsplash.com/photo-1549298916-b41d501d3772?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
        createdAt: new Date(),
      },
      {
        id: 3,
        userId: 1,
        name: "iPhone Case Pro",
        url: "https://example.com/iphone-case",
        category: "Accessories",
        price: "29.99",
        supplierId: 3,
        imageUrl: "https://images.unsplash.com/photo-1556656793-08538906a9f8?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
        createdAt: new Date(),
      },
    ];
    products.forEach(product => this.products.set(product.id, product));

    // Create orders
    const orders: Order[] = [
      {
        id: 12847,
        userId: 1,
        productId: 1,
        supplierId: 1,
        status: "delivered",
        quantity: 1,
        amount: "89.99",
        createdAt: new Date("2023-12-15"),
        updatedAt: new Date("2023-12-15"),
      },
      {
        id: 12846,
        userId: 1,
        productId: 2,
        supplierId: 2,
        status: "processing",
        quantity: 1,
        amount: "124.50",
        createdAt: new Date("2023-12-15"),
        updatedAt: new Date("2023-12-15"),
      },
      {
        id: 12845,
        userId: 1,
        productId: 3,
        supplierId: 3,
        status: "pending",
        quantity: 1,
        amount: "29.99",
        createdAt: new Date("2023-12-14"),
        updatedAt: new Date("2023-12-14"),
      },
    ];
    orders.forEach(order => this.orders.set(order.id, order));

    // Create automations
    const automations: Automation[] = [
      {
        id: 1,
        userId: 1,
        name: "Electronics Auto-Order",
        triggerType: "price_condition",
        triggerCondition: "price < 100",
        action: "place_order",
        parameters: JSON.stringify({ quantity: 10, supplier: "TechSupply" }),
        isActive: true,
        successRate: "95.00",
        lastTriggered: new Date(Date.now() - 2 * 60 * 60 * 1000),
        createdAt: new Date(),
      },
      {
        id: 2,
        userId: 1,
        name: "Weekly Inventory Restock",
        triggerType: "schedule",
        triggerCondition: "every monday 9am",
        action: "check_and_reorder",
        parameters: JSON.stringify({ threshold: 10 }),
        isActive: true,
        successRate: "100.00",
        lastTriggered: null,
        createdAt: new Date(),
      },
    ];
    automations.forEach(automation => this.automations.set(automation.id, automation));

    // Create recent commands
    const commands: Command[] = [
      {
        id: 1,
        userId: 1,
        command: "AUTO-ORDER Nike Shoes WHEN stock<10",
        status: "executed",
        createdAt: new Date(Date.now() - 2 * 60 * 1000),
      },
      {
        id: 2,
        userId: 1,
        command: "SCHEDULE-ORDER Electronics DAILY 9AM",
        status: "executed",
        createdAt: new Date(Date.now() - 15 * 60 * 1000),
      },
    ];
    commands.forEach(command => this.commands.set(command.id, command));

    this.currentId = 20000;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { 
      ...insertUser, 
      id, 
      stripeCustomerId: null,
      stripeSubscriptionId: null,
      createdAt: new Date() 
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserStripeInfo(userId: number, stripeCustomerId: string, stripeSubscriptionId: string): Promise<User | undefined> {
    const user = this.users.get(userId);
    if (!user) return undefined;
    
    const updatedUser = {
      ...user,
      stripeCustomerId,
      stripeSubscriptionId,
      subscriptionPlan: "pro"
    };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  async getProducts(userId: number): Promise<Product[]> {
    return Array.from(this.products.values()).filter(product => product.userId === userId);
  }

  async getProduct(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = this.currentId++;
    const product: Product = { ...insertProduct, id, createdAt: new Date() };
    this.products.set(id, product);
    return product;
  }

  async updateProduct(id: number, updates: Partial<Product>): Promise<Product | undefined> {
    const product = this.products.get(id);
    if (!product) return undefined;
    const updatedProduct = { ...product, ...updates };
    this.products.set(id, updatedProduct);
    return updatedProduct;
  }

  async getSuppliers(): Promise<Supplier[]> {
    return Array.from(this.suppliers.values());
  }

  async getSupplier(id: number): Promise<Supplier | undefined> {
    return this.suppliers.get(id);
  }

  async createSupplier(insertSupplier: InsertSupplier): Promise<Supplier> {
    const id = this.currentId++;
    const supplier: Supplier = { ...insertSupplier, id, createdAt: new Date() };
    this.suppliers.set(id, supplier);
    return supplier;
  }

  async getOrders(userId: number): Promise<Order[]> {
    return Array.from(this.orders.values())
      .filter(order => order.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getRecentOrders(userId: number, limit: number): Promise<Order[]> {
    const orders = await this.getOrders(userId);
    return orders.slice(0, limit);
  }

  async getOrder(id: number): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const id = this.currentId++;
    const order: Order = { 
      ...insertOrder, 
      id, 
      createdAt: new Date(), 
      updatedAt: new Date() 
    };
    this.orders.set(id, order);
    return order;
  }

  async updateOrderStatus(id: number, status: string): Promise<Order | undefined> {
    const order = this.orders.get(id);
    if (!order) return undefined;
    const updatedOrder = { ...order, status, updatedAt: new Date() };
    this.orders.set(id, updatedOrder);
    return updatedOrder;
  }

  async getAutomations(userId: number): Promise<Automation[]> {
    return Array.from(this.automations.values()).filter(automation => automation.userId === userId);
  }

  async getAutomation(id: number): Promise<Automation | undefined> {
    return this.automations.get(id);
  }

  async createAutomation(insertAutomation: InsertAutomation): Promise<Automation> {
    const id = this.currentId++;
    const automation: Automation = { 
      ...insertAutomation, 
      id, 
      createdAt: new Date(),
      successRate: "0.00",
      lastTriggered: null,
    };
    this.automations.set(id, automation);
    return automation;
  }

  async updateAutomation(id: number, updates: Partial<Automation>): Promise<Automation | undefined> {
    const automation = this.automations.get(id);
    if (!automation) return undefined;
    const updatedAutomation = { ...automation, ...updates };
    this.automations.set(id, updatedAutomation);
    return updatedAutomation;
  }

  async getRecentCommands(userId: number, limit: number): Promise<Command[]> {
    return Array.from(this.commands.values())
      .filter(command => command.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, limit);
  }

  async createCommand(insertCommand: InsertCommand): Promise<Command> {
    const id = this.currentId++;
    const command: Command = { ...insertCommand, id, createdAt: new Date() };
    this.commands.set(id, command);
    return command;
  }

  async getOrderMetrics(userId: number): Promise<{
    totalRevenue: number;
    totalOrders: number;
    activeAutomations: number;
    failedOrders: number;
  }> {
    const orders = await this.getOrders(userId);
    const automations = await this.getAutomations(userId);
    
    const totalRevenue = orders.reduce((sum, order) => sum + parseFloat(order.amount), 0);
    const totalOrders = orders.length;
    const activeAutomations = automations.filter(a => a.isActive).length;
    const failedOrders = orders.filter(order => order.status === 'failed').length;

    return {
      totalRevenue,
      totalOrders,
      activeAutomations,
      failedOrders,
    };
  }

  async getQueueStatus(): Promise<{
    pending: number;
    processing: number;
    completed: number;
  }> {
    const allOrders = Array.from(this.orders.values());
    const today = new Date();
    const todayOrders = allOrders.filter(order => 
      order.createdAt.toDateString() === today.toDateString()
    );

    return {
      pending: allOrders.filter(order => order.status === 'pending').length,
      processing: allOrders.filter(order => order.status === 'processing').length,
      completed: todayOrders.filter(order => order.status === 'delivered').length,
    };
  }
}

export const storage = new MemStorage();
