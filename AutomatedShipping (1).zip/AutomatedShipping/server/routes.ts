import type { Express } from "express";
import { createServer, type Server } from "http";
import Stripe from "stripe";
import { storage } from "./storage";

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error('Missing required Stripe secret: STRIPE_SECRET_KEY');
}
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2023-10-16",
});
import { insertProductSchema, insertOrderSchema, insertAutomationSchema, insertCommandSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // Analytics endpoints
  app.get("/api/metrics/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const metrics = await storage.getOrderMetrics(userId);
      res.json(metrics);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch metrics" });
    }
  });

  app.get("/api/queue-status", async (req, res) => {
    try {
      const queueStatus = await storage.getQueueStatus();
      res.json(queueStatus);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch queue status" });
    }
  });

  // Product endpoints
  app.get("/api/products/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const products = await storage.getProducts(userId);
      res.json(products);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch products" });
    }
  });

  app.post("/api/products", async (req, res) => {
    try {
      const validatedData = insertProductSchema.parse(req.body);
      const product = await storage.createProduct(validatedData);
      res.json(product);
    } catch (error) {
      res.status(400).json({ error: "Invalid product data" });
    }
  });

  app.post("/api/products/analyze", async (req, res) => {
    try {
      const { url } = req.body;
      if (!url) {
        return res.status(400).json({ error: "URL is required" });
      }

      // Mock product analysis
      const analysis = {
        name: "Analyzed Product",
        category: "Electronics",
        estimatedPrice: 49.99,
        supplier: "Auto-detected Supplier",
        availability: "In Stock",
        profitMargin: "25%",
      };

      res.json(analysis);
    } catch (error) {
      res.status(500).json({ error: "Failed to analyze product" });
    }
  });

  // Order endpoints
  app.get("/api/orders/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      
      const orders = limit 
        ? await storage.getRecentOrders(userId, limit)
        : await storage.getOrders(userId);
      
      // Join with product and supplier data
      const enrichedOrders = await Promise.all(
        orders.map(async (order) => {
          const product = await storage.getProduct(order.productId);
          const supplier = await storage.getSupplier(order.supplierId);
          return {
            ...order,
            product,
            supplier,
          };
        })
      );

      res.json(enrichedOrders);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch orders" });
    }
  });

  app.post("/api/orders", async (req, res) => {
    try {
      const validatedData = insertOrderSchema.parse(req.body);
      const order = await storage.createOrder(validatedData);
      res.json(order);
    } catch (error) {
      res.status(400).json({ error: "Invalid order data" });
    }
  });

  app.patch("/api/orders/:id/status", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { status } = req.body;
      const order = await storage.updateOrderStatus(id, status);
      if (!order) {
        return res.status(404).json({ error: "Order not found" });
      }
      res.json(order);
    } catch (error) {
      res.status(500).json({ error: "Failed to update order status" });
    }
  });

  // Supplier endpoints
  app.get("/api/suppliers", async (req, res) => {
    try {
      const suppliers = await storage.getSuppliers();
      res.json(suppliers);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch suppliers" });
    }
  });

  // Automation endpoints
  app.get("/api/automations/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const automations = await storage.getAutomations(userId);
      res.json(automations);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch automations" });
    }
  });

  app.post("/api/automations", async (req, res) => {
    try {
      const validatedData = insertAutomationSchema.parse(req.body);
      const automation = await storage.createAutomation(validatedData);
      res.json(automation);
    } catch (error) {
      res.status(400).json({ error: "Invalid automation data" });
    }
  });

  app.patch("/api/automations/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const automation = await storage.updateAutomation(id, updates);
      if (!automation) {
        return res.status(404).json({ error: "Automation not found" });
      }
      res.json(automation);
    } catch (error) {
      res.status(500).json({ error: "Failed to update automation" });
    }
  });

  // Command endpoints
  app.get("/api/commands/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const commands = await storage.getRecentCommands(userId, limit);
      res.json(commands);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch commands" });
    }
  });

  app.post("/api/commands", async (req, res) => {
    try {
      const validatedData = insertCommandSchema.parse(req.body);
      const command = await storage.createCommand(validatedData);
      res.json(command);
    } catch (error) {
      res.status(400).json({ error: "Invalid command data" });
    }
  });

  app.post("/api/commands/execute", async (req, res) => {
    try {
      const { command, userId } = req.body;
      
      if (!command) {
        return res.status(400).json({ error: "Command is required" });
      }

      // Store the command
      await storage.createCommand({
        userId,
        command,
        status: "executed",
      });

      // Mock command execution
      const result = {
        success: true,
        message: "Command executed successfully",
        details: `Processed: ${command}`,
      };

      res.json(result);
    } catch (error) {
      res.status(500).json({ error: "Failed to execute command" });
    }
  });

  return httpServer;
}
